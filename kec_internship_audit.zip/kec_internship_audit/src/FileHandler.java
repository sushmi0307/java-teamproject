import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileHandler {
    private static final Pattern COMPANY_CODE_PATTERN = Pattern.compile("^REG-[A-Z]{2,4}-\\d{4}$");

    public static List<InternshipRecord> parseLogbook(String csvPath) {
        List<InternshipRecord> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvPath))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] parts = line.split(",");
                if (parts.length < 10) continue;
                String studentId = parts[0].trim();
                String name = parts[1].trim();
                String dept = parts[2].trim();
                String category = parts[3].trim();
                String companyCode = parts[4].trim();
                String mentorName = parts[5].trim();
                double mentorRating = Double.parseDouble(parts[6].trim());
                double workReport = Double.parseDouble(parts[7].trim());
                double viva = Double.parseDouble(parts[8].trim());
                String reportText = parts[9].trim();
                InternshipRecord rec = new InternshipRecord(studentId, name, dept, category, companyCode, mentorName);
                rec.setMentorRating(mentorRating);
                rec.setWorkReport(workReport);
                rec.setVivaScore(viva);
                rec.setReportText(reportText);
                rec.setDomainTags(extractDomainTags(reportText));
                records.add(rec);
            }
        } catch (IOException e) {
            System.out.println("[ERROR] Unable to read CSV: " + e.getMessage());
        }
        return records;
    }

    private static List<String> extractDomainTags(String reportText) {
        List<String> tags = new ArrayList<>();
        int idx = reportText.indexOf("tags=");
        if (idx >= 0) {
            String after = reportText.substring(idx + 5);
            String[] split = after.split("[;|]");
            for (String t : split) {
                String clean = t.replaceAll("[^A-Za-z0-9]", "").trim();
                if (!clean.isEmpty()) tags.add(clean);
            }
        }
        return tags;
    }

    public static boolean validateCompanyCode(String code) {
        Matcher m = COMPANY_CODE_PATTERN.matcher(code);
        return m.matches();
    }

    public static void parseAttendance(String attPath, List<InternshipRecord> records) {
        try (BufferedReader br = new BufferedReader(new FileReader(attPath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length != 3) continue;
                String sid = parts[0].trim();
                int days = Integer.parseInt(parts[2].trim());
                for (InternshipRecord r : records) {
                    if (r.getStudentId().equals(sid)) {
                        r.addDaysWorked(days);
                        break;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("[ERROR] Unable to read attendance: " + e.getMessage());
        }
    }

    public static String formatScorecard(InternshipRecord rec) {
        return String.format("%s  %s  %s  MARKS= %.1f Grade=%s Credits=%d %s",
                rec.getStudentId(), rec.getStudentName().toUpperCase(), rec.getCategory(),
                rec.getFinalMarks(), rec.getGrade(), rec.getCredits(), rec.getStatus());
    }
}
