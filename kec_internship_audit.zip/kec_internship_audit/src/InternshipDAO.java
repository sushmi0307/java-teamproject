import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class InternshipDAO {
    private Connection conn;
    private boolean offline;

    public InternshipDAO() {
        this.conn = DBConnection.getConnection();
        this.offline = (this.conn == null);
        if (offline) {
            System.out.println("[DAO] Operating in OFFLINE mode (no DB).");
        }
    }

    // find-or-create mentor and internship placeholder (simplified, no DB ops)
    public void saveInternship(InternshipRecord rec) {
        if (offline) return; // skip DB work
        // In real implementation you would insert mentor and internship rows.
    }

    public void phase1MentorRating(InternshipRecord rec) {
        // placeholder for DB update of mentor rating
        if (offline) return;
    }

    public void phase2ReportMarks(InternshipRecord rec) {
        if (offline) return;
    }

    public void phase3VivaAndDays(InternshipRecord rec) {
        if (offline) return;
    }

    public void saveFinalResult(InternshipRecord rec) {
        if (offline) return;
        // Upsert credits table
    }

    public int getTotalEnrolled() {
        // For IEI calculation, we just return count of records processed elsewhere.
        return 0;
    }
}
