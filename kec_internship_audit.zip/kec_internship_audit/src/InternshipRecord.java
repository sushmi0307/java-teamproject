import java.util.List;
import java.util.ArrayList;

public class InternshipRecord {
    private String studentId;
    private String studentName;
    private String department;
    private String category; // FULL, SUMMER, TRAINING
    private String companyCode;
    private String mentorName;

    private double mentorRating = 0.0;
    private double workReport = 0.0; // report marks or logbook marks
    private double vivaScore = 0.0;
    private String reportText = "";
    private List<String> domainTags = new ArrayList<>();

    private int daysWorked = 0; // from attendance log
    private double finalMarks = 0.0;
    private String grade = "NC";
    private int credits = 0;
    private String status = "PENDING";

    public InternshipRecord(String studentId, String name, String dept, String category,
                            String companyCode, String mentorName) {
        this.studentId = studentId;
        this.studentName = name;
        this.department = dept;
        this.category = category;
        this.companyCode = companyCode;
        this.mentorName = mentorName;
    }

    // Getters & setters
    public String getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public String getDepartment() { return department; }
    public String getCategory() { return category; }
    public String getCompanyCode() { return companyCode; }
    public String getMentorName() { return mentorName; }
    public double getMentorRating() { return mentorRating; }
    public double getWorkReport() { return workReport; }
    public double getVivaScore() { return vivaScore; }
    public String getReportText() { return reportText; }
    public List<String> getDomainTags() { return domainTags; }
    public int getDaysWorked() { return daysWorked; }
    public double getFinalMarks() { return finalMarks; }
    public String getGrade() { return grade; }
    public int getCredits() { return credits; }
    public String getStatus() { return status; }

    public void setMentorRating(double rating) { this.mentorRating = rating; }
    public void setWorkReport(double marks) { this.workReport = marks; }
    public void setVivaScore(double viva) { this.vivaScore = viva; }
    public void setReportText(String text) { this.reportText = text; }
    public void setDomainTags(List<String> tags) { this.domainTags = tags; }

    public void addDaysWorked(int days) { this.daysWorked += days; }

    // Phase computations
    public void computeFinalMarks() {
        switch (category) {
            case "FULL":
                finalMarks = mentorRating * 0.4 + workReport * 0.3 + vivaScore * 0.3;
                break;
            case "SUMMER":
                finalMarks = mentorRating * 0.2 + workReport * 0.5 + vivaScore * 0.3;
                break;
            case "TRAINING":
                finalMarks = workReport * 0.6 + vivaScore * 0.4; // mentor not used
                break;
            default:
                finalMarks = 0.0;
        }
    }

    public int getTotalDaysForCategory() {
        switch (category) {
            case "FULL": return 90;
            case "SUMMER": return 20;
            case "TRAINING": return 10;
            default: return 0;
        }
    }

    private double getThresholdValue() {
        switch (category) {
            case "FULL": return mentorRating;
            case "SUMMER": case "TRAINING": return workReport;
            default: return 0.0;
        }
    }

    private int getCreditsForCategory() {
        switch (category) {
            case "FULL": return 8;
            case "SUMMER": return 3;
            case "TRAINING": return 1;
            default: return 0;
        }
    }

    private int gradePoints() {
        switch (grade) {
            case "O": return 10;
            case "A+": return 9;
            case "A": return 8;
            case "B": return 7;
            default: return 0;
        }
    }

    public void evaluate() {
        computeFinalMarks();
        int totalDays = getTotalDaysForCategory();
        double attendancePct = (totalDays == 0) ? 0.0 : daysWorked * 100.0 / totalDays;
        if (attendancePct < 90.0) {
            status = "INCOMPLETE_STAY";
            grade = "NC";
            credits = 0;
            return;
        }
        double threshold = getThresholdValue();
        if (threshold < 50.0) {
            status = "THRESHOLD_FAIL";
            grade = "NC";
            credits = 0;
            return;
        }
        // grade assignment
        if (finalMarks >= 90) { grade = "O"; }
        else if (finalMarks >= 80) { grade = "A+"; }
        else if (finalMarks >= 70) { grade = "A"; }
        else if (finalMarks >= 60) { grade = "B"; }
        else { grade = "NC"; }
        if (!grade.equals("NC")) {
            status = "COMPLETED";
            credits = getCreditsForCategory();
        } else {
            status = "COMPLETED"; // still completed but NC grade, keep credits 0
            credits = 0;
        }
    }

    public int getGradePoints() { return gradePoints(); }
}
