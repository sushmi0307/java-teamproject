CREATE DATABASE IF NOT EXISTS kec_internship;
USE kec_internship;

CREATE TABLE mentors (
    mentor_id INT AUTO_INCREMENT PRIMARY KEY,
    mentor_name VARCHAR(100) NOT NULL,
    company_code VARCHAR(20) NOT NULL
);

CREATE TABLE internships (
    internship_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    student_name VARCHAR(100) NOT NULL,
    department VARCHAR(50),
    category ENUM('FULL','SUMMER','TRAINING') NOT NULL,
    company_code VARCHAR(20) NOT NULL,
    mentor_id INT,
    total_days INT NOT NULL,
    FOREIGN KEY (mentor_id) REFERENCES mentors(mentor_id)
);

CREATE TABLE evaluations (
    eval_id INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT NOT NULL UNIQUE,
    mentor_rating DECIMAL(5,2),
    report_marks DECIMAL(5,2),
    viva_score DECIMAL(5,2),
    days_worked INT,
    domain_tags VARCHAR(255),
    final_marks DECIMAL(5,2),
    grade VARCHAR(2),
    status VARCHAR(30),
    FOREIGN KEY (internship_id) REFERENCES internships(internship_id)
);

CREATE TABLE credits (
    credit_id INT AUTO_INCREMENT PRIMARY KEY,
    internship_id INT NOT NULL UNIQUE,
    credits_awarded INT,
    grade_points INT,
    FOREIGN KEY (internship_id) REFERENCES internships(internship_id)
);

CREATE USER 'kecuser'@'10.0.0.%' IDENTIFIED BY 'Kec@2026';
GRANT ALL PRIVILEGES ON kec_internship.* TO 'kecuser'@'10.0.0.%';
FLUSH PRIVILEGES;
