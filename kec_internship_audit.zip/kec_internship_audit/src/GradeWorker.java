import java.util.List;
import java.util.concurrent.Callable;
import java.io.FileWriter;
import java.io.IOException;

public class GradeWorker implements Callable<List<InternshipRecord>> {
    private List<InternshipRecord> records;

    public GradeWorker(List<InternshipRecord> records) {
        this.records = records;
    }

    @Override
    public List<InternshipRecord> call() throws Exception {
        for (InternshipRecord rec : records) {
            rec.evaluate();
            System.out.println(String.format("[%s] %s", Thread.currentThread().getName(), FileHandler.formatScorecard(rec)));
        }
        return records;
    }
}
