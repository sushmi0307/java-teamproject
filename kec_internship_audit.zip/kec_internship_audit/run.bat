@echo off
rem Compile Java source files
set CLASSPATH=lib/*;.
javac -cp "%CLASSPATH%" -d out src/*.java
if %errorlevel% neq 0 (
    echo Compilation failed.
    exit /b %errorlevel%
)
rem Run the application
java -cp "out;lib/*" MainApp
