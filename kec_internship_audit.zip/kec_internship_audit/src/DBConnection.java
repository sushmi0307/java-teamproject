import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection = null;

    public static Connection getConnection() {
        if (connection != null) return connection;
        String host = System.getenv().getOrDefault("DB_HOST", "localhost");
        String port = System.getenv().getOrDefault("DB_PORT", "3306");
        String db = System.getenv().getOrDefault("DB_NAME", "kec_internship");
        String user = System.getenv().getOrDefault("DB_USER", "kecuser");
        String pass = System.getenv().getOrDefault("DB_PASS", "Kec@2026");
        String url = "jdbc:mysql://" + host + ":" + port + "/" + db + "?useSSL=false&allowPublicKeyRetrieval=true";
        try {
            connection = DriverManager.getConnection(url, user, pass);
            System.out.println("[DB] Connected to " + url);
        } catch (SQLException e) {
            System.out.println("[DB] MySQL unreachable (" + e.getMessage() + ") -> OFFLINE mode");
            connection = null;
        }
        return connection;
    }
}
