import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.io.FileWriter;
import java.io.IOException;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("=== KEC INTERNSHIP & INDUSTRIAL TRAINING AUDIT SYSTEM ===\n");
        // DB connection attempt (handled inside DBConnection)
        DBConnection.getConnection();

        // Parse CSV
        String csvPath = "data/internship_logbook.csv";
        List<InternshipRecord> allRecords = FileHandler.parseLogbook(csvPath);
        List<InternshipRecord> validRecords = new ArrayList<>();
        int rejected = 0;
        System.out.println("--- LOGBOOK CSV PARSING & COMPANY CODE VALIDATION ---");
        for (InternshipRecord rec : allRecords) {
            if (FileHandler.validateCompanyCode(rec.getCompanyCode())) {
                System.out.println("[SAVED] " + rec.getStudentId() + " - " + rec.getStudentName().toUpperCase() + " (" + rec.getCategory() + ") " + rec.getCompanyCode());
                validRecords.add(rec);
            } else {
                System.out.println("[INVALID] Company Registration Code rejected: " + rec.getCompanyCode() + " (" + rec.getStudentId() + ")");
                rejected++;
            }
        }
        System.out.println("\nImport completed: " + validRecords.size() + " accepted, " + rejected + " rejected.\n");

        InternshipDAO dao = new InternshipDAO();
        // Phase 1
        System.out.println("--- PHASE 1 (MID-TERM): INDUSTRY MENTOR PROGRESS RATING ---");
        for (InternshipRecord rec : validRecords) {
            dao.phase1MentorRating(rec);
            String mentorInfo = rec.getCategory().equals("TRAINING") ? "N/A (logbook-based)" : String.format("mentor rating = %.1f", rec.getMentorRating());
            System.out.println("[PHASE-1] " + rec.getStudentId() + "  " + rec.getStudentName().toUpperCase() + "  " + mentorInfo);
        }
        // Phase 2
        System.out.println("--- PHASE 2 (END-TERM): TECHNICAL WORK REPORT / LOGBOOK MARKS ---");
        for (InternshipRecord rec : validRecords) {
            dao.phase2ReportMarks(rec);
            String domains = String.join(",", rec.getDomainTags());
            System.out.println("[PHASE-2] " + rec.getStudentId() + "  " + rec.getStudentName().toUpperCase() + "    marks = " + String.format("%.1f", rec.getWorkReport()) + "  domains = " + domains);
        }
        // Phase 3 - attendance
        FileHandler.parseAttendance("data/attendance_log.txt", validRecords);
        System.out.println("--- PHASE 3 (POST-TERM): VIVA SCORE & VERIFIED DAYS (attendance_log.txt) ---");
        for (InternshipRecord rec : validRecords) {
            dao.phase3VivaAndDays(rec);
            System.out.println("[PHASE-3] " + rec.getStudentId() + "  " + rec.getStudentName().toUpperCase() + "    viva = " + String.format("%.1f", rec.getVivaScore()) + "  days = " + rec.getDaysWorked() + "/" + rec.getTotalDaysForCategory());
        }

        // Multithreaded grade evaluation per category
        System.out.println("--- MULTITHREADED PANEL-WISE GRADE EVALUATION ---");
        Map<String, List<InternshipRecord>> byCat = new HashMap<>();
        for (InternshipRecord rec : validRecords) {
            byCat.computeIfAbsent(rec.getCategory(), k -> new ArrayList<>()).add(rec);
        }
        ExecutorService exec = Executors.newFixedThreadPool(3);
        List<Future<List<InternshipRecord>>> futures = new ArrayList<>();
        for (Map.Entry<String, List<InternshipRecord>> e : byCat.entrySet()) {
            futures.add(exec.submit(new GradeWorker(e.getValue())));
        }
        exec.shutdown();
        // Wait for completion (implicitly when futures get())
        for (Future<List<InternshipRecord>> f : futures) {
            try { f.get(); } catch (Exception ex) { ex.printStackTrace(); }
        }

        // After evaluation, generate reports
        generateOutputs(validRecords);
    }

    private static void generateOutputs(List<InternshipRecord> records) {
        // Ensure output directories exist
        java.io.File outDir = new java.io.File("output");
        java.io.File certDir = new java.io.File(outDir, "certificates");
        outDir.mkdirs();
        certDir.mkdirs();
        // audit_report.txt
        try (FileWriter fw = new FileWriter(new java.io.File(outDir, "audit_report.txt"))) {
            for (InternshipRecord rec : records) {
                fw.write(FileHandler.formatScorecard(rec) + "\n");
            }
        } catch (IOException e) { e.printStackTrace(); }
        // IEI calculation
        int totalEnrolled = records.size();
        int sum = 0;
        for (InternshipRecord rec : records) {
            sum += rec.getCredits() * rec.getGradePoints();
        }
        double iei = totalEnrolled == 0 ? 0 : (double) sum / totalEnrolled;
        try (FileWriter fw = new FileWriter(new java.io.File(outDir, "iei_summary.txt"))) {
            fw.write("IEI = Sum(Credits x GradePoints) / TotalEnrolled = " + sum + " / " + totalEnrolled + " = " + String.format("%.2f", iei));
        } catch (IOException e) { e.printStackTrace(); }
        // certificates for COMPLETED and grade != NC
        for (InternshipRecord rec : records) {
            if (rec.getStatus().equals("COMPLETED") && !rec.getGrade().equals("NC")) {
                java.io.File certPath = new java.io.File(certDir, "CERT_" + rec.getStudentId() + ".txt");
                try (FileWriter fw = new FileWriter(certPath)) {
                    fw.write("Certificate of Completion\n");
                    fw.write(rec.getStudentName() + " (" + rec.getStudentId() + ") has successfully completed the " + rec.getCategory() + " internship.\n");
                    fw.write("Grade: " + rec.getGrade() + "\n");
                    fw.write("Credits Earned: " + rec.getCredits() + "\n");
                } catch (IOException e) { e.printStackTrace(); }
            }
        }
        System.out.println("\n--- INDUSTRIAL EXPOSURE INDEX ---");
        System.out.println("IEI = Sum(Credits x GradePoints) / TotalEnrolled = " + sum + " / " + totalEnrolled + " = " + String.format("%.2f", iei));
        System.out.println("\n--- PROJECT OUTPUT FILES CREATED ---");
        System.out.println("1. " + new java.io.File(outDir, "audit_report.txt").getPath());
        System.out.println("2. " + new java.io.File(outDir, "iei_summary.txt").getPath());
        System.out.println("3. " + certDir.getPath() + " (" + countCertificates(records) + " completion certificates)");
        System.out.println("\nProject execution completed.");
    }

    private static int countCertificates(List<InternshipRecord> records) {
        int cnt = 0;
        for (InternshipRecord rec : records) {
            if (rec.getStatus().equals("COMPLETED") && !rec.getGrade().equals("NC")) cnt++;
        }
        return cnt;
    }
}
